# Cas de figure Archive X-Ray

Archive pédagogique fictive. Aucun malware réel ni identifiant fonctionnel. Ne pas utiliser pour prouver une détection exhaustive.

Les noms dangereux sont des exemples ; aucune extraction n’est nécessaire pour la démo.
