# Archive pédagogique

Tous les pièges sont fictifs : aucun malware réel.
Le secret est un motif synthétique volontaire.
