![Image externe](https://example.invalid/pixel)
<script>alert("Jamais exécuté")</script>
