---
name: validation
description: Vérifier un rendu
---
Exiger des résultats de tests réels.
