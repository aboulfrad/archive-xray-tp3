export const isValid = (value: number) => Number.isFinite(value);
