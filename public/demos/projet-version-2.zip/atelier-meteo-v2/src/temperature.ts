export function celsiusToFahrenheit(celsius: number): number {
  if (!Number.isFinite(celsius)) throw new Error("Température invalide");
  return celsius * 9 / 5 + 32;
}
