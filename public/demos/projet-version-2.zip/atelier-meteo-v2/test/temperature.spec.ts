import { expect, test } from 'vitest';
import { celsiusToFahrenheit } from '../src/temperature';
test('point de congélation', () => {
  expect(celsiusToFahrenheit(0)).toBe(32);
});
