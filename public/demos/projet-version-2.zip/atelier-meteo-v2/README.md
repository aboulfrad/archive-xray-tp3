# Atelier météo

Projet fictif de démonstration.

## Démarrer
```sh
npm ci
npm run dev
```

## Vérifier
```sh
npm run check
```

Les configurations présentes ne prouvent pas leur exécution.
