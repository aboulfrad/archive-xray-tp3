---
description: Inspection sans modification
mode: subagent
permission:
  edit: deny
  bash: deny
---
Vérifier les preuves.
