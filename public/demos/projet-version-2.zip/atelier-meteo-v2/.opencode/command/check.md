Lancer npm run check et conserver le résultat exact.
