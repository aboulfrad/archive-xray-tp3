# Règles
Lire le cahier des charges. Les échecs bloquent la livraison.
